from django.urls import path, include
from . import views



urlpatterns = [
     path('main/', views.predictor, name='main'),
     path('', views.login_view, name='login'),
    path('register/', views.register, name='register'),
    path('logout/', views.logout_view, name='logout'),
]
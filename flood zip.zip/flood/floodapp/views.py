from django.shortcuts import render
from django.http import HttpResponse
from joblib import load
import numpy as np
import pandas as pd

ensemble_model = load('./savedModels/ensemble_model.joblib')


from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from .forms import RegistrationForm, LoginForm

# Registration view
def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            messages.success(request, 'Registration successful! Please log in.')
            return redirect('login')  # Redirect to login page after successful registration
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})

# Login view
def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('main')  # Redirect to the main page
            else:
                messages.error(request, 'Invalid username or password.')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

# Logout view
def logout_view(request):
    logout(request)
    return redirect('login')


from django.contrib.auth.decorators import login_required

@login_required
def predictor(request):
    if request.method == 'POST':
        param1 = float(request.POST.get('param1'))
        param2 = float(request.POST.get('param2'))
        param3 = float(request.POST.get('param3'))
        param4 = float(request.POST.get('param4'))
        param5 = float(request.POST.get('param5'))
        param6 = float(request.POST.get('param6'))
        param7 = float(request.POST.get('param7'))
        param8 = float(request.POST.get('param8'))
        param9 = float(request.POST.get('param9'))
        param10 = float(request.POST.get('param10'))
        param11 = float(request.POST.get('param11'))
        param12 = float(request.POST.get('param12'))
        param13 = float(request.POST.get('param13'))


        user_input = [[67.450578,118.127103,0.97,15.69,16.46,23.483476,0.97,24.55,34.06,3.68000,5.500000,3.770000,25]]
        # print(model.predict(user_input))
        m = [[param1, param2, param3, param4, param5, param6,param7, param8, param9, param10, param11, param12, param13]]

        feature_names = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC',
                         ' ANNUAL RAINFALL']  # Note the leading space

        # Create a DataFrame for the new data point
        print(m)
        new_value = pd.DataFrame(m, columns=feature_names)
        print(new_value)

        # Predict for the new value
        result = ensemble_model.predict(new_value)

        #print(ensemble_model.predict(m))
        #result = ensemble_model.predict(m)

        if(result[0] == 0):
            overall = "Floods will not occur"
        elif(result[0] == 1):
            overall = "Floods will occur"

        monthly_values = [param1, param2, param3, param4, param5, param6, param7, param8, param9, param10, param11,
                          param12]

        # Find the top 3 values and corresponding feature names (from months)
        top_3_indices = sorted(range(len(monthly_values)), key=lambda i: monthly_values[i], reverse=True)[:3]
        top_3_months = [feature_names[i] for i in top_3_indices]
        top_3_values = [monthly_values[i] for i in top_3_indices]

        return render(request, 'main.html', {'result': result[0], 'overall':overall, 'top_3_months': top_3_months,'top_3_values': top_3_values})

    return render(request, 'main.html')

''' import joblib
import pandas as pd
import numpy as np
import skfuzzy as fuzz
from django.shortcuts import render

# Load the model using joblib
model = joblib.load('./savedModels/ensemble_model.joblib')

def apply_fuzzy_logic_annual_rainfall(X):
    # Define the fuzzy logic system for " ANNUAL RAINFALL"
    col = " ANNUAL RAINFALL"  # Notice the leading space here
    col_min = X[col].min()
    col_max = X[col].max()
    col_mean = X[col].mean()

    # Generate a range of values for the membership functions
    x_range = np.linspace(col_min, col_max, 100)

    # Create membership functions
    low_mf = fuzz.trimf(x_range, [col_min, col_min, col_mean])
    medium_mf = fuzz.trimf(x_range, [col_min, col_mean, col_max])
    high_mf = fuzz.trimf(x_range, [col_mean, col_max, col_max])

    fuzzy_values = []
    for value in X[col]:
        if value <= col_mean:
            fuzzy_value = fuzz.interp_membership(x_range, low_mf, value)
        elif value > col_mean and value <= col_max:
            fuzzy_value = fuzz.interp_membership(x_range, medium_mf, value)
        else:
            fuzzy_value = fuzz.interp_membership(x_range, high_mf, value)
        fuzzy_values.append(fuzzy_value)

    # Replace the original " ANNUAL RAINFALL" column with fuzzy values
    X[col] = fuzzy_values
    return X

def predictor(request):
    if request.method == 'POST':
        print(request.POST)  # Debugging: See what keys are being posted

        try:
            # Extract input data from POST request
            input_data = [
                float(request.POST['JAN']),
                float(request.POST['FEB']),
                float(request.POST['MAR']),
                float(request.POST['APR']),
                float(request.POST['MAY']),
                float(request.POST['JUN']),
                float(request.POST['JUL']),
                float(request.POST['AUG']),
                float(request.POST['SEP']),
                float(request.POST['OCT']),
                float(request.POST['NOV']),
                float(request.POST['DEC']),
                float(request.POST['ANNUAL_RAINFALL']),
            ]
        except KeyError as e:
            return HttpResponse(f"Missing field in POST data: {e}")

        # Prepare input data for prediction
        input_data_df = pd.DataFrame([input_data], columns=['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC', ' ANNUAL RAINFALL'])

        # Apply fuzzy logic to the input data
        input_data_fuzzy = apply_fuzzy_logic_annual_rainfall(input_data_df)

        # Make prediction
        prediction = model.predict(input_data_fuzzy)
        print(prediction)
        prediction_result = 'Flood' if prediction[0] == 1 else 'No Flood'

        # Render result in a template
        return render(request, 'main.html', {'result': prediction_result})

    return render(request, 'main.html') '''


